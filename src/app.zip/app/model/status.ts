export enum Status {
    Default = 'DEFAULT',
    Completed = 'COMPLETED',
    Delete = 'DELETED'
  };